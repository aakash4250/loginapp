package com.example.loginapp;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class HelloController {

    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Button loginButton;

    private final String correctUsername = "Aakash";  // Static username
    private final String correctPassword = "456";     // Static password
    private int loginAttempts = 0;
    private final int maxAttempts = 5;

    @FXML
    private void initialize() {
        loginButton.setOnAction(event -> handleLogin());
    }

    private void handleLogin() {
        String enteredUsername = usernameField.getText();
        String enteredPassword = passwordField.getText();

        if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
            showAlert("Error", "Please Provide Username or Password.");
        } else if (loginAttempts >= maxAttempts) {
            showAlert("Error", "Sorry, Your Account is Locked!!!");
        } else {
            if (enteredUsername.equals(correctUsername) && enteredPassword.equals(correctPassword)) {
                showAlert("Success", "Success!!!");
            } else {
                loginAttempts++;
                if (loginAttempts >= maxAttempts) {
                    showAlert("Error", "Sorry, Your Account is Locked!!!");
                } else {
                    showAlert("Error", "Sorry, Invalid Username or Password. Attempts left: " + (maxAttempts - loginAttempts));
                }
            }
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
